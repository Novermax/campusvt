/**
 * scorm.js — Campus VT SCORM 1.2 Bridge v6
 * Embedded Docebo multi-SCO: ogni item lancia un tutorial specifico
 * Legge location.search ?sco=TUTORIAL_ID passato da adlcp:parameters
 * Debug: indicatore visivo + catch-all messages
 */
(function () {
  'use strict';

  // ─── CONFIGURAZIONE ─────────────────────────────────────────────────────────
  // Modifica per il tuo deployment Docebo
  var CVT_BASE_URL = 'https://novermax.github.io/campusvt/';
  var CVT_LANG = '';           // 'ita','eng','deu','fra' — '' = default (eng)

  // Legge il parametro ?sco= dalla URL (passato tramite adlcp:parameters nel manifest)
  var SCO_ID = null;
  try {
    var q = new URLSearchParams(window.location.search);
    SCO_ID = q.get('sco') || null;
  } catch(e) {}

  // ─── INDICATORE VISIVO ────────────────────────────────────────────────────
  function showIndicator(text, color) {
    var el = document.getElementById('scorm-indicator');
    if (!el) {
      el = document.createElement('div');
      el.id = 'scorm-indicator';
      el.style.cssText = [
        'position:fixed','top:8px','right:8px',
        'padding:8px 14px','border-radius:6px',
        'font-family:Arial,sans-serif','font-size:12px',
        'font-weight:bold','z-index:2147483647',
        'max-width:320px','word-break:break-all',
        'box-shadow:0 2px 8px rgba(0,0,0,0.4)',
        'transition:background 0.3s'
      ].join(';');
      document.body.appendChild(el);
    }
    el.style.background = color || '#0055cc';
    el.style.color = '#fff';
    el.innerHTML = text;
  }

  // ─── SCORM API ─────────────────────────────────────────────────────────────
  var API = null;

  function findAPI(win) {
    var w = win;
    var attempts = 0;
    while (w.API == null && w.parent != null && w.parent !== w) {
      attempts++;
      if (attempts > 10) break;
      w = w.parent;
    }
    if (w.API) return w.API;
    try {
      if (win.opener && win.opener.API) return win.opener.API;
      if (win.opener && win.opener.parent && win.opener.parent.API)
        return win.opener.parent.API;
    } catch (e) {}
    return null;
  }

  function initSCORM() {
    API = findAPI(window);
    if (!API) {
      showIndicator('\u26a0\ufe0f SCORM API non trovata', '#cc3300');
      return false;
    }
    var result = API.LMSInitialize('');
    console.log('[SCORM] LMSInitialize:', result);
    showIndicator('\u2705 SCORM pronto<br>API: ' + (!!API) + ' | Init: ' + result, '#006600');
    return result === 'true' || result === true;
  }

  // ─── STATO ─────────────────────────────────────────────────────────────────
  var sessionStart = Date.now();
  var currentScore = 0;
  var isCompleted  = false;
  var suspendData  = {};
  var msgCount     = 0;

  function sessionTimeStr() {
    var sec = Math.floor((Date.now() - sessionStart) / 1000);
    var h = String(Math.floor(sec / 3600)).padStart(2, '0');
    var m = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
    var s = String(sec % 60).padStart(2, '0');
    return h + ':' + m + ':' + s;
  }

  function doCommit(score, status) {
    if (!API) return;
    API.LMSSetValue('cmi.core.session_time', sessionTimeStr());
    API.LMSSetValue('cmi.core.score.raw',    String(score));
    API.LMSSetValue('cmi.core.score.min',    '0');
    API.LMSSetValue('cmi.core.score.max',    '100');
    API.LMSSetValue('cmi.core.lesson_status', status);
    try { API.LMSSetValue('cmi.suspend_data', JSON.stringify(suspendData).substring(0, 4096)); } catch(e) {}
    API.LMSCommit('');
  }

  function showCompletionOverlay(score, status) {
    var passed = status === 'passed';
    var overlay = document.createElement('div');
    overlay.id = 'scorm-completion-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.82);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:99999;font-family:Arial,sans-serif;color:#fff;text-align:center;padding:24px';
    overlay.innerHTML =
      '<div style="font-size:4rem;margin-bottom:16px">' + (passed ? '\ud83c\udf89' : '\ud83d\udccb') + '</div>' +
      '<h2 style="font-size:1.6rem;margin-bottom:8px">' + (passed ? 'Tutorial completato!' : 'Sessione terminata') + '</h2>' +
      '<p style="font-size:1.4rem;font-weight:bold;margin-bottom:28px">Punteggio: ' + score + '/100</p>' +
      '<button id="scorm-close-btn" style="background:#0073e6;color:#fff;border:none;padding:14px 36px;font-size:1rem;border-radius:6px;cursor:pointer;font-weight:bold">Torna alla piattaforma</button>' +
      '<p style="font-size:0.8rem;opacity:0.5;margin-top:16px">Chiusura automatica tra 15 secondi</p>';
    document.body.appendChild(overlay);
    document.getElementById('scorm-close-btn').addEventListener('click', closeSession);
    setTimeout(closeSession, 15000);
  }

  function closeSession() {
    if (API) API.LMSFinish('');
    try { window.close(); } catch(e) {}
    var el = document.getElementById('scorm-completion-overlay');
    if (el) el.innerHTML = '<p style="font-size:1.1rem;color:#fff;font-family:Arial">Puoi chiudere questa finestra e tornare alla piattaforma.</p>';
  }

  // ─── URL CVT DINAMICO ──────────────────────────────────────────────────────
  function buildCVTUrl() {
    var params = [];
    params.push('autologin=1');

    // Student name from LMS
    var studentName = '';
    try {
      if (API) {
        var name = API.LMSGetValue('cmi.core.student_name');
        if (name && name !== '') studentName = name;
      }
    } catch(e) {}
    if (studentName) params.push('user=' + encodeURIComponent(studentName));

    // Lingua
    if (CVT_LANG) params.push('lang=' + encodeURIComponent(CVT_LANG));

    // Tutorial specifico passato da adlcp:parameters nel manifest
    if (SCO_ID) {
      params.push('tutorials=' + encodeURIComponent(SCO_ID));
      // In modalità singolo SCO la home non serve
      params.push('noHome=1');
    }

    // Sequential sempre attivo per gli SCO singoli
    params.push('sequential=1');

    return CVT_BASE_URL + '?' + params.join('&');
  }

  // ─── PERSISTENZA COMPLETATI (suspend_data) ────────────────────────────────
  function loadCompletedIds() {
    try {
      var raw = API ? API.LMSGetValue('cmi.suspend_data') : '';
      if (raw) {
        var parsed = JSON.parse(raw);
        if (parsed._completedIds && Array.isArray(parsed._completedIds)) {
          showIndicator('\ud83d\udcc2 Ripristinati ' + parsed._completedIds.length + ' completamenti', '#995500');
          return parsed._completedIds;
        }
      }
    } catch(e) {}
    return [];
  }

  function saveCompletedId(scenarioId) {
    try {
      var raw = API ? API.LMSGetValue('cmi.suspend_data') : '';
      var sd = {};
      try { sd = JSON.parse(raw || '{}'); } catch(e) {}
      sd._completedIds = sd._completedIds || [];
      if (sd._completedIds.indexOf(scenarioId) === -1) {
        sd._completedIds.push(scenarioId);
        suspendData = sd;
        if (API) {
          API.LMSSetValue('cmi.suspend_data', JSON.stringify(sd).substring(0, 4096));
          API.LMSCommit('');
        }
        showIndicator('\ud83d\udcbe Completamento salvato: ' + scenarioId, '#995500');
      }
    } catch(e) {}
  }

  // ─── CATCH-ALL: logga TUTTO ──────────────────────────────────────────────
  window.addEventListener('message', function(e) {
    msgCount++;
    var preview = '';
    try { preview = JSON.stringify(e.data).substring(0, 60); } catch(ex) { preview = String(e.data); }
    console.log('[SCORM] MSG #' + msgCount + ' da:', e.origin, '\u2192', preview);
    showIndicator('\ud83d\udce8 MSG #' + msgCount + '<br>da: ' + e.origin + '<br>' + preview, '#0055cc');
  }, false);

  // ─── HANDLER EVENTI CVT ───────────────────────────────────────────────────
  window.addEventListener('message', function(e) {
    var d = e.data;
    if (!d || !d.type || !d.type.startsWith('vt:')) return;

    console.log('[SCORM] evento CVT:', d.type, d);
    showIndicator('\ud83c\udfae CVT: ' + d.type, '#005500');

    switch (d.type) {
      case 'vt:session_init':
        if (d.userName) API && API.LMSSetValue('cmi.core.student_name', d.userName);
        doCommit(0, 'incomplete');
        break;
      case 'vt:tutorial_start':
        API && API.LMSSetValue('cmi.core.lesson_location', d.tutorialId || '');
        doCommit(0, 'incomplete');
        break;
      case 'vt:step_complete':
        var idx = d.stepIndex != null ? d.stepIndex : 0;
        suspendData[idx] = { title: d.stepTitle || '', durationMs: d.durationMs || 0, errors: d.errors || 0 };
        API && API.LMSSetValue('cmi.core.lesson_location', String(idx));
        doCommit(currentScore, 'incomplete');
        break;
      case 'vt:tutorial_complete':
        currentScore = Math.min(100, Math.max(0, Math.round(d.score || 0)));
        isCompleted  = true;
        var status   = currentScore >= 60 ? 'passed' : 'failed';
        try { suspendData['_summary'] = { totalTimeMs: d.totalTimeMs, score: currentScore, steps: d.stepTimings }; } catch(e) {}
        doCommit(currentScore, status);

        // Persisti scenarioId nel suspend_data per ripresa cross-sessione
        if (d.scenarioId) {
          saveCompletedId(d.scenarioId);
        }

        showCompletionOverlay(currentScore, status);
        break;
    }
  });

  window.addEventListener('beforeunload', function() {
    var st = isCompleted ? (currentScore >= 60 ? 'passed' : 'failed') : 'incomplete';
    doCommit(currentScore, st);
    if (API) API.LMSFinish('');
  });

  // ─── INIT ─────────────────────────────────────────────────────────────────
  initSCORM();

  // Imposta URL iframe con parametri embedded
  var iframe = document.getElementById('vt_frame');
  if (iframe) {
    iframe.src = buildCVTUrl();
  }

  // Leggi completati da LMS suspend_data
  var completedIds = loadCompletedIds();

  // Quando iframe carica CVT, invia completati per sync
  if (iframe) {
    iframe.addEventListener('load', function onLoad() {
      iframe.removeEventListener('load', onLoad);
      if (completedIds.length > 0) {
        setTimeout(function() {
          try {
            iframe.contentWindow.postMessage({
              type: 'cvt:sync_completed',
              completedIds: completedIds
            }, '*');
            showIndicator('\ud83d\udce4 Inviati ' + completedIds.length + ' completamenti a CVT', '#006600');
          } catch(e) {
            console.warn('[SCORM] Errore sync completati:', e);
          }
        }, 2000);
      }
    });
  }

  console.log('[SCORM] Bridge v6 pronto. API:', !!API, '| SCO:', SCO_ID, '| URL:', iframe ? iframe.src : 'N/A');

})();
