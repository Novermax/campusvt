# 🔴 CRITICITÀ: Sistema Rotazione Viti Non Funzionante

**Data**: 5 Dicembre 2025
**Priorità**: ALTA
**Sistema Coinvolto**: Animazioni svita/avvita viti (scene3d-modular.js)

---

## 📋 Descrizione Problema

Le viti **NON ruotano visibilmente** durante le animazioni di svitamento/avvitamento, nonostante il codice preveda rotazioni di 1800° (5 giri completi).

### Sintomi Osservati
- ✅ **Traslazione funziona**: Le viti si muovono lungo l'asse configurato (es. Z per viti culatta)
- ❌ **Rotazione non visibile**: Le viti rimangono immobili durante svitamento
- ⚠️ **Comportamento inconsistente**: A volte movimento orbitale indesiderato invece di rotazione su se stesse

---

## 🔍 Analisi Tecnica

### Causa Root Identificata
**Problema**: Rotazione applicata attorno all'**origin locale del file GLB**, non al **centro geometrico** (bounding box center)

```javascript
// Codice attuale (scene3d-modular.js:2241-2274)
// Calcola rotazione compensata per mantenere movimento lineare del centro BB
const rotationMatrix = new THREE.Matrix4();
rotationMatrix.makeRotationFromEuler(rotationDelta);
const rotatedOffset = initialOffset.clone().applyMatrix4(rotationMatrix);
newPosition = currentBBCenter.clone().add(rotatedOffset);
```

**Problema**: Se l'origin del GLB è spostato rispetto al centro del bounding box, la rotazione genera:
1. Movimento orbitale invece di rotazione su se stessa
2. Offset non compensato correttamente
3. Posizione finale errata

### Configurazione Corrente
**File**: `scenes/Pompa_Becker/home_config.txt`
```ini
model=models/vite_culatta_1.glb
direction=0,0,1    # Direzione svitamento lungo Z
```

**File**: `scenes/Pompa_Becker/tutorial.txt`
```ini
[Step 1 - Rimuovi vite 1 culatta]
Elemento=models/vite_culatta_1.glb
Utensile=ChiaveBrugola
Azione1=svita    # Dovrebbe ruotare 1800° + traslare 0.5 unità lungo Z
```

**Parametri Animazione** (`scene3d-modular.js:1753-1773`):
```javascript
rotazione: {
    x: direction.x * 1800,  // 5 giri completi (1800°)
    y: direction.y * 1800,
    z: direction.z * 1800
}
traslazione: {
    x: direction.x * 0.5,  // Movimento lineare 0.5 unità
    y: direction.y * 0.5,
    z: direction.z * 0.5
}
```

---

## 🎯 Risultato Atteso vs Risultato Reale

### Risultato Atteso
1. **Movimento Lineare**: Centro BB della vite si muove linearmente lungo Z di +0.5 unità
2. **Rotazione Visibile**: La vite ruota su se stessa di 1800° (5 giri completi orari) attorno all'asse Z
3. **Nessun Offset**: La geometria rimane intatta, nessun movimento orbitale

### Risultato Reale
1. ✅ **Movimento Lineare**: Centro BB si muove correttamente lungo Z
2. ❌ **Rotazione Non Visibile**: La vite non ruota visibilmente, appare immobile
3. ⚠️ **Possibile Movimento Orbitale**: A volte la vite orbita invece di ruotare su se stessa

---

## 🔧 Tentativi di Fix Precedenti

### Sistema Rotazione Compensata (Gennaio 2026)
**Commit**: Sistema Rotazione Viti Durante Svitamento
**File Modificato**: `js/scene3d-modular.js:2241-2274`

**Strategia**:
1. Il centro del BB si muove linearmente
2. Calcolo offset tra `model.position` e centro BB iniziale
3. Rotazione dell'offset per compensare rotazione attorno origin locale
4. Nuova posizione = centro BB corrente + offset ruotato

**Problema Riscontrato**:
- La compensazione offset funziona matematicamente
- Ma la rotazione visibile della geometria rimane assente/inconsistente
- Possibile problema: `model.rotation` applica rotazione all'origin locale, che potrebbe essere lontano dal centro geometrico

### Inversione Direzione Rotazione (Gennaio 2026)
**Commit**: Aggiornamento Rotazioni Svita/Avvita + Rotazioni Coerenti con Direction
**Modifiche**:
- Inversione direzione: svita da -180° → +1800° (5 giri orario)
- Rimozione `Math.abs()`: rotazioni ora rispettano segno `direction`

**Risultato**: Nessun miglioramento visibile

---

## 📊 Test Case Problematici

### Viti Culatta (`direction=0,0,1`)
- **Step 1-4**: Svita vite_culatta_1, vite_culatta_2, vite_culatta_3, vite_culatta_4
- **Comportamento**: Si muovono lungo Z, **NO rotazione visibile**
- **Posizioni Finali**: Corrette (0.5 unità lungo Z)

### Viti Coperchio (`direction=-1,0,0`)
- **Step Smontaggio**: Svita 4 viti coperchio
- **Comportamento**: Si muovono lungo -X, **NO rotazione visibile**
- **Rotazione Attesa**: `rotazione.x = -1 × 1800 = -1800°` (5 giri antiorario)

---

## 💡 Possibili Soluzioni da Investigare

### Opzione 1: Rotazione Attorno a Punto Arbitrario
Invece di ruotare `model.rotation` (origin-based), applicare rotazione attorno al centro BB usando matrici di trasformazione:

```javascript
// Pseudo-codice
const pivot = boundingBoxCenter;
const rotationAxis = new THREE.Vector3(direction.x, direction.y, direction.z).normalize();
const rotationMatrix = new THREE.Matrix4().makeRotationAxis(rotationAxis, angleInRadians);

// Applica rotazione attorno a pivot
model.position.sub(pivot);           // Sposta al pivot
model.position.applyMatrix4(rotationMatrix);  // Ruota
model.position.add(pivot);           // Riporta indietro

// Applica rotazione al modello
model.rotation.setFromRotationMatrix(rotationMatrix);
```

### Opzione 2: Fix File GLB Origin
Ri-esportare tutti i file GLB con origin al centro geometrico invece che offset:
- **Pro**: Fix permanente, codice semplificato
- **Contro**: Richiede rielaborazione tutti i modelli viti in Blender

### Opzione 3: Wrapper Object per Pivot
Creare un `THREE.Group` con pivot al centro BB, aggiungere vite come child, ruotare il gruppo:

```javascript
const pivotGroup = new THREE.Group();
pivotGroup.position.copy(boundingBoxCenter);
pivotGroup.add(model);
model.position.sub(boundingBoxCenter); // Offset relativo al gruppo

// Ruota il gruppo invece del modello
pivotGroup.rotation.z += angleInRadians;
```

### Opzione 4: Debug Visuale Origin
Aggiungere helper visuale per visualizzare:
- Origin locale del modello (punto di rotazione)
- Centro del bounding box (dove dovrebbe ruotare)
- Assi rotazione

```javascript
// Helper origin
const originHelper = new THREE.AxesHelper(0.05);
model.add(originHelper);

// Helper centro BB
const centerHelper = new THREE.SphereGeometry(0.01, 8, 8);
const centerMesh = new THREE.Mesh(centerHelper, new THREE.MeshBasicMaterial({color: 0xff0000}));
centerMesh.position.copy(boundingBoxCenter);
```

---

## 🧪 Test Diagnostici Richiesti

### 1. Verifica Origin GLB
```javascript
// Console
const vite = Scene3D.findModelByName('vite_culatta_1');
const bbox = new THREE.Box3().setFromObject(vite);
const center = bbox.getCenter(new THREE.Vector3());
console.log('Model position:', vite.position);
console.log('BB Center:', center);
console.log('Offset:', vite.position.clone().sub(center));
```

**Output Atteso**: Se offset ≠ (0,0,0), origin è spostato rispetto al centro

### 2. Test Rotazione Manuale
```javascript
// Ruota manualmente la vite di 90° attorno a Z
const vite = Scene3D.findModelByName('vite_culatta_1');
vite.rotation.z += Math.PI / 2;  // 90°
```

**Verifica**: La vite ruota visibilmente? Se sì, il problema è nel sistema di compensazione offset.

### 3. Test Rotazione Attorno Centro BB
```javascript
// Applica rotazione attorno al centro BB usando matrici
const vite = Scene3D.findModelByName('vite_culatta_1');
const bbox = new THREE.Box3().setFromObject(vite);
const pivot = bbox.getCenter(new THREE.Vector3());

// Salva posizione iniziale
const initialPos = vite.position.clone();

// Sposta al pivot, ruota, riporta indietro
vite.position.sub(pivot);
vite.rotation.z += Math.PI / 2;  // 90°
vite.position.applyAxisAngle(new THREE.Vector3(0,0,1), Math.PI / 2);
vite.position.add(pivot);
```

---

## 📁 File Coinvolti

### Codice JavaScript
- `js/scene3d-modular.js:1753-1792` - Configurazione rotazioni svita/avvita
- `js/scene3d-modular.js:2228-2274` - Algoritmo rotazione compensata
- `js/scene3d-modular.js:2001-2344` - Esecuzione animazioni

### Configurazioni Tutorial
- `scenes/Pompa_Becker/home_config.txt` - Configurazione `direction` per ogni modello vite
- `scenes/Pompa_Becker/tutorial.txt:33-119` - Step 1-4 svita viti culatta

### Modelli 3D
- `models/vite_culatta_1.glb` (e vite_culatta_2,3,4)
- `models/vite_coperchio_1.glb` (e vite_coperchio_2,3,4)
- `models/vite_estrattore.glb`

---

## 🎯 Obiettivo Fix

**Requisiti**:
1. ✅ Viti ruotano **visibilmente** di 1800° durante svita/avvita
2. ✅ Centro BB si muove **linearmente** lungo direction configurata
3. ✅ **Nessun movimento orbitale** indesiderato
4. ✅ Rotazione **coerente** con segno direction (orario/antiorario)
5. ✅ **Zero breaking changes** per tutorial esistenti

**Successo**: Utente vede chiaramente le viti ruotare su se stesse mentre si svitano/avvitano, movimento fluido e realistico.

---

## 📞 Informazioni Aggiuntive

Per ulteriori dettagli vedere:
- `CLAUDE.md:1630-1707` - Documentazione Sistema Rotazione Viti
- `CLAUDE.md:1708-1749` - Rotazioni Coerenti con Direction
- `console.txt` - Log debug completi esecuzione animazioni

---

**Status**: 🔴 **BLOCCANTE** - Le animazioni viti sono parte fondamentale del tutorial smontaggio pompa. Fix richiesto prima di release produzione.
