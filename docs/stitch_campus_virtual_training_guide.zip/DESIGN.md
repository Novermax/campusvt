---
name: Campus Industrial Precision
colors:
  surface: '#131314'
  surface-dim: '#131314'
  surface-bright: '#39393a'
  surface-container-lowest: '#0e0e0f'
  surface-container-low: '#1b1b1c'
  surface-container: '#1f1f20'
  surface-container-high: '#2a2a2b'
  surface-container-highest: '#353436'
  on-surface: '#e5e2e3'
  on-surface-variant: '#c0c7d3'
  inverse-surface: '#e5e2e3'
  inverse-on-surface: '#303031'
  outline: '#8a919c'
  outline-variant: '#404751'
  surface-tint: '#9bcbff'
  primary: '#9bcbff'
  on-primary: '#003256'
  primary-container: '#3b96e2'
  on-primary-container: '#002c4b'
  inverse-primary: '#00629f'
  secondary: '#7ddc7a'
  on-secondary: '#00390a'
  secondary-container: '#03711e'
  on-secondary-container: '#92f28e'
  tertiary: '#c6c6c7'
  on-tertiary: '#2f3131'
  tertiary-container: '#909191'
  on-tertiary-container: '#282a2a'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d0e4ff'
  primary-fixed-dim: '#9bcbff'
  on-primary-fixed: '#001d34'
  on-primary-fixed-variant: '#004a79'
  secondary-fixed: '#98f994'
  secondary-fixed-dim: '#7ddc7a'
  on-secondary-fixed: '#002204'
  on-secondary-fixed-variant: '#005313'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#131314'
  on-background: '#e5e2e3'
  surface-variant: '#353436'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
spacing:
  base: 8px
  gutter: 24px
  margin: 48px
  grid_columns: '12'
  container_max: 1200px
---

## Brand & Style

This design system establishes a visual bridge between heavy industrial machinery and cutting-edge virtual training software. The personality is authoritative, systematic, and educational, tailored for technicians and engineers who value precision and clarity.

The aesthetic follows a **Corporate / Modern** direction with a heavy emphasis on **Industrial Minimalism**. It utilizes a "Technical Schematic" layer—geometric overlays and blueprint-style line art—to ground the software imagery in real-world mechanical contexts. The interface should feel like a high-end operating manual: organized, high-contrast, and focused on functional hierarchy.

Key visual pillars include:
*   **Precision Geometry:** Use of 45-degree angles and technical line weights.
*   **Structural Clarity:** Clear separation of content through tonal layering.
*   **Machined Accuracy:** Sharp edges mixed with subtle industrial textures.

## Colors

The palette is derived from the "Campus Virtual Training" UI, emphasizing a professional "Dark Mode" environment common in industrial control software.

*   **Primary (Action Blue):** Used for primary instructional headings and active state indicators.
*   **Secondary (Success Green):** Reserved for "Completed" states, safety indicators, and progress markers.
*   **Neutral (Mechanical Black/Gray):** The foundation of the system. Grays are neutral-to-cool, mimicking cast iron and brushed steel.
*   **High-Contrast Accents:** Bright Cyan and White are used for technical overlays (schematics) to ensure legibility against dark backgrounds.

Color application should follow a 60-30-10 distribution: 60% Dark Neutrals, 30% Industrial Grays, and 10% vibrant Blue/Green accents for information signaling.

## Typography

This design system uses two distinct sans-serif families to balance technical character with readability.

**Space Grotesk** is used for headlines and labels. Its geometric, slightly futuristic construction echoes technical drawings and digital interfaces. Use "Label-caps" for metadata, such as part numbers or chapter codes, to reinforce the industrial feel.

**Inter** is the workhorse for body text and instructions. Its high x-height and neutral character ensure that dense technical manuals remain legible during long training sessions. 

Keep line lengths for body text between 60-75 characters to maintain educational accessibility.

## Layout & Spacing

The layout is built on a **12-column fixed grid** that mimics a technical blueprint. 

*   **Rhythm:** An 8px base unit (the "modular step") governs all margins and padding. 
*   **Asymmetry:** While the grid is fixed, content should feel dynamic. Use "Technical Offsets" where text blocks may span 5 columns while leaving 1 column empty for schematic callouts.
*   **Overlays:** Technical schematics (thin lines and coordinates) should bleed off the edges of the grid, creating a sense of a larger "mechanical universe" beyond the frame of the page or screen.
*   **Negative Space:** Significant breathing room is required around 3D renders of machinery to allow the primary blue/green accents to pop.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** rather than traditional shadows. In this design system, depth mimics the physical layering of hardware components.

*   **Level 0 (Background):** Pure mechanical black or the darkest gray.
*   **Level 1 (Panels):** Surfaces slightly lighter than the background (Surface Industrial), used for grouping related controls or text.
*   **Technical Glass:** A subtle backdrop-blur effect (Glassmorphism) is applied to labels that hover over 3D machinery renders, ensuring legibility without obscuring the machine's detail.
*   **Outlines:** Use 1px solid borders in primary blue or bright gray to define interactive zones. Avoid soft shadows; prefer crisp, high-contrast edges that suggest machined precision.

## Shapes

The design system adopts a **Sharp (0)** roundedness philosophy. 

All buttons, cards, and containers feature 90-degree corners to reflect industrial metalwork and structural beams. To add visual interest without compromising the industrial feel, use **chamfered corners** (45-degree angled cuts) on primary action buttons and navigation tabs. This echoes the "chevron" style buttons seen in the Virtual Training UI, creating a strong sense of direction and process flow.

## Components

*   **Process Tabs:** Based on the software's bottom navigation, these are rectangular blocks with a chevron-shaped end. Use the Primary Blue for standard steps and Secondary Green for the "current" or "completed" focus.
*   **Callout Tags:** Small, high-contrast labels (Level 1 surface) connected to machinery by 1px "leader lines" (schematic overlays). 
*   **Instructional Cards:** Flat panels with a 2px top-border in the accent color to indicate category (e.g., Blue for "Operation," Green for "Maintenance").
*   **Inputs:** Minimalist fields defined only by a bottom border or a low-opacity gray fill, using monospaced font for numerical values.
*   **Data Badges:** Pill-shaped text elements are strictly forbidden; use rectangular tags with monospaced "Space Grotesk" text for technical specs or software versions.
*   **Iconography:** Use "Stroke" style icons with consistent 1.5px or 2px weights. Icons should be strictly functional, representing tools, safety warnings, or directional movement.