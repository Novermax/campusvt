/**
 * scorm.js ? Campus VT SCORM 1.2 Bridge v6
 * SCO: pompa_becker ? Lingua: fra
 */
(function () {
  'use strict';
  var CVT_BASE_URL = 'https://novermax.github.io/campusvt/';
  var SCO_ID = 'pompa_becker';
  var CVT_LANG = 'fra';
  function showIndicator(text, color) {
    var el = document.getElementById('scorm-indicator');
    if (!el) {
      el = document.createElement('div');
      el.id = 'scorm-indicator';
      el.style.cssText = 'position:fixed;top:8px;right:8px;padding:8px 14px;border-radius:6px;font-family:Arial,sans-serif;font-size:12px;font-weight:bold;z-index:2147483647;max-width:320px;word-break:break-all;box-shadow:0 2px 8px rgba(0,0,0,0.4);transition:background 0.3s';
      document.body.appendChild(el);
    }
    el.style.background = color || '#0055cc';
    el.style.color = '#fff';
    el.innerHTML = text;
  }
  var API = null;
  function findAPI(win) {
    var w = win, attempts = 0;
    while (w.API == null && w.parent != null && w.parent !== w) {
      attempts++; if (attempts > 10) break; w = w.parent;
    }
    if (w.API) return w.API;
    try { if (win.opener && win.opener.API) return win.opener.API; if (win.opener && win.opener.parent && win.opener.parent.API) return win.opener.parent.API; } catch(e) {}
    return null;
  }
  function initSCORM() {
    API = findAPI(window);
    if (!API) { showIndicator('\u26a0\ufe0f SCORM API non trovata', '#cc3300'); return false; }
    var result = API.LMSInitialize('');
    console.log('[SCORM] LMSInitialize:', result);
    showIndicator('\u2705 SCORM pronto | Init: ' + result, '#006600');
    return result === 'true' || result === true;
  }
  var sessionStart = Date.now(), currentScore = 0, isCompleted = false, suspendData = {}, msgCount = 0;
  function sessionTimeStr() {
    var sec = Math.floor((Date.now() - sessionStart) / 1000);
    return String(Math.floor(sec / 3600)).padStart(2, '0') + ':' + String(Math.floor((sec % 3600) / 60)).padStart(2, '0') + ':' + String(sec % 60).padStart(2, '0');
  }
  function doCommit(score, status) {
    if (!API) return;
    API.LMSSetValue('cmi.core.session_time', sessionTimeStr());
    API.LMSSetValue('cmi.core.score.raw', String(score));
    API.LMSSetValue('cmi.core.score.min', '0');
    API.LMSSetValue('cmi.core.score.max', '100');
    API.LMSSetValue('cmi.core.lesson_status', status);
    try { API.LMSSetValue('cmi.suspend_data', JSON.stringify(suspendData).substring(0, 4096)); } catch(e) {}
    API.LMSCommit('');
  }
  function showCompletionOverlay(score, status) {
    var passed = status === 'passed';
    var overlay = document.createElement('div');
    overlay.id = 'scorm-completion-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.82);display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:99999;font-family:Arial,sans-serif;color:#fff;text-align:center;padding:24px';
    overlay.innerHTML = '<div style="font-size:4rem;margin-bottom:16px">' + (passed ? '\ud83c\udf89' : '\ud83d\udccb') + '</div><h2 style="font-size:1.6rem;margin-bottom:8px">' + (passed ? 'Tutorial completato!' : 'Sessione terminata') + '</h2><p style="font-size:1.4rem;font-weight:bold;margin-bottom:28px">Punteggio: ' + score + '/100</p><button id="scorm-close-btn" style="background:#0073e6;color:#fff;border:none;padding:14px 36px;font-size:1rem;border-radius:6px;cursor:pointer;font-weight:bold">Torna alla piattaforma</button><p style="font-size:0.8rem;opacity:0.5;margin-top:16px">Chiusura automatica tra 15 secondi</p>';
    document.body.appendChild(overlay);
    document.getElementById('scorm-close-btn').addEventListener('click', closeSession);
    setTimeout(closeSession, 15000);
  }
  function closeSession() {
    if (API) API.LMSFinish('');
    try { window.close(); } catch(e) {}
    var el = document.getElementById('scorm-completion-overlay');
    if (el) el.innerHTML = '<p style="font-size:1.1rem;color:#fff;font-family:Arial">Puoi chiudere questa finestra e tornare alla piattaforma.</p>';
  }
  function buildCVTUrl() {
    var params = [];
    params.push('autologin=1');
    var studentName = '';
    try { if (API) { var name = API.LMSGetValue('cmi.core.student_name'); if (name && name !== '') studentName = name; } } catch(e) {}
    if (studentName) params.push('user=' + encodeURIComponent(studentName));
    params.push('lang=' + encodeURIComponent(CVT_LANG));
    if (SCO_ID) { params.push('tutorials=' + encodeURIComponent(SCO_ID)); params.push('noHome=1'); }
    params.push('sequential=1');
    return CVT_BASE_URL + '?' + params.join('&');
  }
  function loadSuspendData() {
    try {
      var raw = API ? API.LMSGetValue('cmi.suspend_data') : '';
      if (raw) return JSON.parse(raw);
    } catch(e) {}
    return {};
  }
  function saveSuspendData() {
    if (!API) return;
    try { API.LMSSetValue('cmi.suspend_data', JSON.stringify(suspendData).substring(0, 4096)); API.LMSCommit(''); } catch(e) {}
  }
  function loadCompletedIds() {
    if (suspendData._completedIds && Array.isArray(suspendData._completedIds)) return suspendData._completedIds;
    return [];
  }
  function saveCompletedId(scenarioId) {
    suspendData._completedIds = suspendData._completedIds || [];
    if (suspendData._completedIds.indexOf(scenarioId) === -1) { suspendData._completedIds.push(scenarioId); saveSuspendData(); }
  }
  suspendData = loadSuspendData();
  if (suspendData._lang && suspendData._lang !== CVT_LANG) {
    console.log('[SCORM] Cambio lingua:', suspendData._lang, '\u2192', CVT_LANG, '? reset sessione');
    showIndicator('\ud83d\udd04 Cambio lingua: reset sessione', '#cc6600');
    suspendData = { _lang: CVT_LANG };
    saveSuspendData();
    if (API) { API.LMSSetValue('cmi.core.lesson_location', ''); API.LMSSetValue('cmi.core.score.raw', '0'); API.LMSSetValue('cmi.core.lesson_status', 'incomplete'); API.LMSCommit(''); }
  } else { suspendData._lang = CVT_LANG; saveSuspendData(); }
  window.addEventListener('message', function(e) {
    msgCount++;
    var preview = ''; try { preview = JSON.stringify(e.data).substring(0, 60); } catch(ex) { preview = String(e.data); }
    console.log('[SCORM] MSG #' + msgCount + ' da:', e.origin, '\u2192', preview);
  }, false);
  window.addEventListener('message', function(e) {
    var d = e.data;
    if (!d || !d.type || !d.type.startsWith('vt:')) return;
    switch (d.type) {
      case 'vt:session_init': if (d.userName) API && API.LMSSetValue('cmi.core.student_name', d.userName); doCommit(0, 'incomplete'); break;
      case 'vt:tutorial_start': API && API.LMSSetValue('cmi.core.lesson_location', d.tutorialId || ''); doCommit(0, 'incomplete'); break;
      case 'vt:step_complete': var idx = d.stepIndex != null ? d.stepIndex : 0; suspendData[idx] = { title: d.stepTitle || '', durationMs: d.durationMs || 0, errors: d.errors || 0 }; API && API.LMSSetValue('cmi.core.lesson_location', String(idx)); doCommit(currentScore, 'incomplete'); break;
      case 'vt:tutorial_complete': currentScore = Math.min(100, Math.max(0, Math.round(d.score || 0))); isCompleted = true; var status = currentScore >= 60 ? 'passed' : 'failed'; try { suspendData['_summary'] = { totalTimeMs: d.totalTimeMs, score: currentScore, steps: d.stepTimings }; } catch(e) {} doCommit(currentScore, status); if (d.scenarioId) saveCompletedId(d.scenarioId); showCompletionOverlay(currentScore, status); break;
    }
  });
  window.addEventListener('beforeunload', function() {
    var st = isCompleted ? (currentScore >= 60 ? 'passed' : 'failed') : 'incomplete';
    doCommit(currentScore, st); if (API) API.LMSFinish('');
  });
  initSCORM();
  var iframe = document.getElementById('vt_frame');
  if (iframe) iframe.src = buildCVTUrl();
  var completedIds = loadCompletedIds();
  if (iframe) {
    iframe.addEventListener('load', function onLoad() {
      iframe.removeEventListener('load', onLoad);
      if (completedIds.length > 0) {
        setTimeout(function() { try { iframe.contentWindow.postMessage({ type: 'cvt:sync_completed', completedIds: completedIds }, '*'); } catch(e) {} }, 2000);
      }
    });
  }
  console.log('[SCORM] SCO:', SCO_ID, '| LANG:', CVT_LANG, '| URL:', iframe ? iframe.src : 'N/A');
})();
